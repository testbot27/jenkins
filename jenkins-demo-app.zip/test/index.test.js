console.log("Test passed: App is working.");
